import random

# Function to create the game board
def create_board(size):
    board = []
    for _ in range(size):
        row = ["O"] * size
        board.append(row)
    return board

# Function to display the game board
def display_board(board):
    for row in board:
        print(" ".join(row))

# Function to place the battleship randomly on the board
def place_battleship(board, ship_size):
    row = random.randint(0, len(board) - 1)
    col = random.randint(0, len(board[0]) - 1)

    horizontal = random.choice([True, False])

    if horizontal:
        if col + ship_size > len(board[0]):
            col = len(board[0]) - ship_size
        for i in range(ship_size):
            board[row][col + i] = "B"
    else:
        if row + ship_size > len(board):
            row = len(board) - ship_size
        for i in range(ship_size):
            board[row + i][col] = "B"

# Function to play the game
def play_battleship(board, user_board,ship_size,attempts) :
    place_battleship(board, ship_size)
    display_board(user_board)
    print("Let's play Battleship!")
    print("You have", attempts, "attempts to sink the battleship.")

    for attempt in range(attempts):
        print("\nAttempt", attempt + 1)
        guess_row = int(input("Guess Row: "))
        guess_col = int(input("Guess Col: "))

        if board[guess_row][guess_col] == "B":
            print("Congratulations! You sank the battleship!")
            display_board(board)
            break
        else:
            if guess_row not in range(len(board)) or guess_col not in range(len(board[0])):
                print("Oops, that's not even in the ocean.")
            elif board[guess_row][guess_col] == "X":
                print("You guessed that one already.")
            else:
                print("You missed the battleship!")
                board[guess_row][guess_col] = "X"
                user_board[guess_row][guess_col]="X"
                display_board(user_board) #display play user
            if attempt >= 5: 
                print("Try To Hit 'B' below") #suggestion
                display_board(board)
            if attempt == attempts - 1:
                print("Game Over! The battleship was here:")
                display_board(board)


# Main function to start the game
def main():
    ship_size = 3  # Size of the battleship
    attempts = 8  # Number of attempts allowed
    board_size = 10  # Size of the game board
    solution_game_board = create_board(board_size)
    user_game_board = create_board(board_size)
    play_battleship(solution_game_board, user_game_board,ship_size,attempts)

if __name__ == "__main__":
    main()
